# Auto dark mode theme for [Standard Notes](https://standardnotes.org)

<br>

## Installation

1. Open the Standard Notes Desktop App

2. In the Extensions menu, click 'Import Extension' and paste:
`https://raw.githubusercontent.com/danielcommesse/sn-auto-dark-mode/main/ext.json`

3. Click 'Install'

4. Activate the theme!
